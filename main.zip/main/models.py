from django.db import models

# Create your models here.
class Main(models.Model):
    site_name = models.CharField(verbose_name="Имя сайта", max_length=50)
    logo = models.ImageField(verbose_name="Логотип сайта", upload_to='logo/')

    def __str__(self):
        return self.site_name

    class Meta:
        verbose_name = 'Настройка'
        verbose_name_plural = 'Настройки'