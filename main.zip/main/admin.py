from django.contrib import admin

# Register your models here.
from main.models import Main


@admin.register(Main)
class MainAdmin(admin.ModelAdmin):
    list_display = ('site_name',)